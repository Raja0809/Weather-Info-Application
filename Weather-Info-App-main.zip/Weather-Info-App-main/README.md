# Weather-Info-App
Our weather app will show the weather information that it will get from API , weather description and users city and country

